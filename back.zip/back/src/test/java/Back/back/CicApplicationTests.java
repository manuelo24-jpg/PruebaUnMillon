package Back.back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicApplicationTests {

	@Test
	void contextLoads() {
	}

}
